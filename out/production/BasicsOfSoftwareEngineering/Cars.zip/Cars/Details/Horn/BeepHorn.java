package Cars.Details.Horn;

public class BeepHorn implements Horn{
    @Override
    public String sound() {
        return "Beep-Beep";
    }
}
