package Cars.Details.Horn;

public interface Horn {
    public String sound();
}
