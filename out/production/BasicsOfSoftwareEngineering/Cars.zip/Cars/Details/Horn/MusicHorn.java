package Cars.Details.Horn;

public class MusicHorn implements Horn{
    @Override
    public String sound() {
        return "Badum-tssssss";
    }
}
