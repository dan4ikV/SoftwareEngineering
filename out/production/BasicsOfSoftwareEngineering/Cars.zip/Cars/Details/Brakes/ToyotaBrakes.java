package Cars.Details.Brakes;

public class ToyotaBrakes implements Brakes {
    @Override
    public double breakingDistance() {
        return 2.5;
    }
}
