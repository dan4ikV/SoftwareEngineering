package Cars.Details.Brakes;

public class BMWBrakes implements Brakes {
    @Override
    public double breakingDistance() {
        return 1.9;
    }
}
