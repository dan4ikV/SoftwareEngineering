package Cars.Details.Brakes;

public class MercedesBrakes implements Brakes {
    @Override
    public double breakingDistance() {
        return 1.6;
    }
}
