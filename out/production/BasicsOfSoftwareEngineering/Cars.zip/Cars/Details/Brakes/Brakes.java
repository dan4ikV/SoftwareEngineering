package Cars.Details.Brakes;

public interface Brakes {
    double breakingDistance();
}
