package Cars.Details.Suspension;

public interface Suspension {
    int controllability();
}
