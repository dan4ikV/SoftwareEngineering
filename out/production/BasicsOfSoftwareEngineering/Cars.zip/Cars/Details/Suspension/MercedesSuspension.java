package Cars.Details.Suspension;

public class MercedesSuspension implements Suspension{
    @Override
    public int controllability() {
        return 8;
    }
}
