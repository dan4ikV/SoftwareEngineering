package Cars.Details.Suspension;

public class BMWSuspension implements Suspension{
    @Override
    public int controllability() {
        return 9;
    }
}
