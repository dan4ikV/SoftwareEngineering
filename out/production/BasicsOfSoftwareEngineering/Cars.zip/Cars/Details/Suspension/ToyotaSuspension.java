package Cars.Details.Suspension;

public class ToyotaSuspension implements Suspension{
    @Override
    public int controllability() {
        return 7;
    }
}
