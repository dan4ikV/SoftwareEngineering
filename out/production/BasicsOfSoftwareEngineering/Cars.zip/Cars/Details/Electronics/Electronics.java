package Cars.Details.Electronics;

public interface Electronics {
    boolean parkingCamera();
    boolean nativeGPS();
}
