package Cars.Details.Engines;

public interface Engine {
    double maxSpeed();
    double litersPer100Km();
}
